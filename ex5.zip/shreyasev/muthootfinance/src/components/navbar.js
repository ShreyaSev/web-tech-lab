import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () =>{
    return (
        <div className='navBar'>
            <div className='home'>
                <Link to="/">Home</Link>
            </div>
            <div className='services'>
                <Link to = "/services">Services</Link>
            </div>
            <div className='corporate'>
                <Link to="/corporate">Corporate</Link>
            </div>
        </div>
    )
}

export default Navbar;