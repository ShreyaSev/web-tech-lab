import React from "react";

function Corporate(){
    return (
        <div className="corporate">
            <h1>Corporate</h1>
        </div>
    )
}

export default Corporate;
